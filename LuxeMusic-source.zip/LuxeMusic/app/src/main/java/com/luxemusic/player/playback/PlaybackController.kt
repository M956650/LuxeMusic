package com.luxemusic.player.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.luxemusic.player.domain.Track

class PlaybackController(context: Context) {
    private var controller: MediaController? = null
    var onTrackChanged: ((Track?) -> Unit)? = null
    var onPlayingChanged: ((Boolean) -> Unit)? = null
    private var queue: List<Track> = emptyList()
    private var currentIndex = 0
    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { onPlayingChanged?.invoke(isPlaying) }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { publishCurrent() }
    }
    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({ runCatching { future.get() }.onSuccess { controller = it; it.addListener(listener) } }, MoreExecutors.directExecutor())
    }
    fun play(tracks: List<Track>, selected: Track) {
        queue = tracks
        currentIndex = tracks.indexOfFirst { it.id == selected.id }.coerceAtLeast(0)
        val items = tracks.map { MediaItem.Builder().setMediaId(it.id.toString()).setUri(Uri.parse(it.uri)).build() }
        controller?.setMediaItems(items, currentIndex, 0L)
        controller?.prepare(); controller?.play(); publishCurrent()
    }
    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun skipNext() { controller?.seekToNextMediaItem() }
    fun skipPrevious() { controller?.seekToPreviousMediaItem() }
    private fun publishCurrent() { val id = controller?.currentMediaItem?.mediaId?.toLongOrNull(); onTrackChanged?.invoke(queue.firstOrNull { it.id == id }) }
    fun release() { controller?.removeListener(listener); controller?.release(); controller = null }
}
