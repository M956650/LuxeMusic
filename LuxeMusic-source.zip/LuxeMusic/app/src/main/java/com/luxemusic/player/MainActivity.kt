package com.luxemusic.player

import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.luxemusic.player.data.LocalAudioScanner
import com.luxemusic.player.domain.Track
import com.luxemusic.player.playback.PlaybackController
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var playback: PlaybackController
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        playback = PlaybackController(this)
        setContent { LuxeApp(playback) }
    }
    override fun onDestroy() { playback.release(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LuxeApp(player: PlaybackController) {
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selectedTab by remember { mutableStateOf("HOME") }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val dark = Color(0xFF090A0F)
    val panel = Color(0xFF171923)
    val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    var hasAudioPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasAudioPermission = granted
        if (granted) tracks = runCatching { LocalAudioScanner(context).scan() }.getOrDefault(emptyList())
    }
    LaunchedEffect(Unit) {
        player.onTrackChanged = { current = it }
        player.onPlayingChanged = { playing = it }
        if (hasAudioPermission) tracks = runCatching { LocalAudioScanner(context).scan() }.getOrDefault(emptyList())
        else permissionLauncher.launch(audioPermission)
    }
    MaterialTheme(colorScheme = darkColorScheme(background = dark, surface = panel, primary = Color(0xFFE7B978))) {
        Scaffold(containerColor = dark, bottomBar = {
            Column {
                current?.let { track ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).background(panel, RoundedCornerShape(16.dp)).clickable { selectedTab = "NOW PLAYING" }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, null, tint = Color(0xFFE7B978), modifier = Modifier.size(32.dp))
                        Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(track.title, maxLines = 1, fontWeight = FontWeight.SemiBold); Text(track.artist, color = Color.LightGray, style = MaterialTheme.typography.labelSmall) }
                        IconButton(onClick = { player.toggle() }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause") }
                        IconButton(onClick = { player.skipNext() }) { Icon(Icons.Default.SkipNext, "Next") }
                    }
                }
                NavigationBar(containerColor = dark) {
                    listOf("HOME" to Icons.Default.Home, "LIBRARY" to Icons.Default.LibraryMusic, "SEARCH" to Icons.Default.Search, "SETTINGS" to Icons.Default.Settings).forEach { (name, icon) ->
                        NavigationBarItem(selected = selectedTab == name, onClick = { selectedTab = name }, icon = { Icon(icon, name) }, label = { Text(name) })
                    }
                }
            }
        }) { padding ->
            when (selectedTab) {
                "SEARCH" -> Column(Modifier.padding(padding).padding(20.dp)) {
                    Text("Search your music", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Songs, artists, albums…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    TrackList(tracks.filter { "${it.title} ${it.artist} ${it.album}".contains(query, true) }, { player.play(tracks, it) })
                }
                "LIBRARY" -> Column(Modifier.padding(padding).padding(20.dp)) {
                    Text("Your Library", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("${tracks.size} songs on this device", color = Color.LightGray)
                    TrackList(tracks, { player.play(tracks, it) })
                }
                "SETTINGS" -> Column(Modifier.padding(padding).padding(20.dp)) {
                    Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Luxe Music • Offline player", color = Color.LightGray, modifier = Modifier.padding(top = 12.dp))
                    Text("Music is scanned from local device storage. Android media permission is required.", modifier = Modifier.padding(top = 12.dp))
                    Button(onClick = { if (hasAudioPermission) tracks = runCatching { LocalAudioScanner(context).scan() }.getOrDefault(emptyList()) else permissionLauncher.launch(audioPermission) }, modifier = Modifier.padding(top = 16.dp)) { Text(if (hasAudioPermission) "Rescan music" else "Grant music access") }
                }
                "NOW PLAYING" -> current?.let { track ->
                    Column(Modifier.padding(padding).fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF403B55), dark))).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Brush.linearGradient(listOf(Color(0xFFB58B62), Color(0xFF302C40))), RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Album, null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.size(112.dp)) }
                        Spacer(Modifier.height(28.dp)); Text(track.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 1); Text(track.artist, color = Color.LightGray)
                        Spacer(Modifier.height(28.dp)); Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { player.skipPrevious() }) { Icon(Icons.Default.SkipPrevious, null, modifier = Modifier.size(38.dp)) }
                            IconButton(onClick = { player.toggle() }, modifier = Modifier.size(72.dp).background(Color(0xFFE7B978), RoundedCornerShape(50))) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = dark, modifier = Modifier.size(42.dp)) }
                            IconButton(onClick = { player.skipNext() }) { Icon(Icons.Default.SkipNext, null, modifier = Modifier.size(38.dp)) }
                        }
                    }
                } ?: Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { Text("Choose a song to start listening") }
                else -> Column(Modifier.padding(padding).padding(20.dp)) {
                    Text("Good evening", color = Color.LightGray)
                    Text("Your music,\nyour moment.", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF463B5A), Color(0xFF202331))), RoundedCornerShape(24.dp)).padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("YOUR LIBRARY", color = Color(0xFFE7B978), style = MaterialTheme.typography.labelMedium); Text("${tracks.size} local tracks", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("No internet required", color = Color.LightGray) }
                        Icon(Icons.Default.Headphones, null, modifier = Modifier.size(54.dp), tint = Color(0xFFE7B978))
                    }
                    Spacer(Modifier.height(22.dp)); Text("Recently available", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    TrackList(tracks.take(30), { player.play(tracks, it) })
                }
            }
        }
    }
}

@Composable
private fun TrackList(items: List<Track>, onClick: (Track) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
        items(items, key = { it.id }) { track ->
            Row(Modifier.fillMaxWidth().clickable { onClick(track) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Color(0xFF282A36), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color(0xFFE7B978)) }
                Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(track.title, maxLines = 1, fontWeight = FontWeight.Medium); Text(track.artist, maxLines = 1, color = Color.LightGray, style = MaterialTheme.typography.bodySmall) }
                Text(formatDuration(track.duration), color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
private fun formatDuration(ms: Long): String = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)
