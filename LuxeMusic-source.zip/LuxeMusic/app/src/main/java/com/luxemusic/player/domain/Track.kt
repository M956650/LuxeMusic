package com.luxemusic.player.domain

data class Track(val id: Long, val uri: String, val title: String, val artist: String, val album: String, val duration: Long, val mimeType: String?)
