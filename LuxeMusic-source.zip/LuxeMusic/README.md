# Luxe Music — Android offline music player (starter implementation)

Native Android project using Kotlin, Jetpack Compose, Media3, MediaSession and MediaStore. Package: `com.luxemusic.player`. Minimum Android: 12 / API 31.

## Current implementation
- Native Compose Android app (not a WebView).
- Home, Library, Search, Settings and Now Playing views.
- Local audio discovery through MediaStore for devices that grant `READ_MEDIA_AUDIO`.
- MP3/AAC/FLAC/WAV/M4A/OGG/OPUS playback depends on Android/Media3 decoder support on the device.
- Media3 ExoPlayer-backed media session service and queue playback.
- Mini-player controls and synchronized basic playing state.
- Rescan action and local search.

## Not yet implemented / not verified
This is an initial source-code foundation, **not the complete feature set in the specification**. Room persistence, playlists/favourites, folder browsing and exclusions, full playback progress/seek, artwork extraction and dynamic colors, equalizer/effects, sleep timer, speed/shuffle/repeat UI, DataStore settings, Hilt wiring, advanced animations, and automated/device QA remain to be implemented. A basic runtime audio permission request is wired for Android 12/13+. Do not treat those features as working.

## Build
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder in Android Studio and allow Gradle sync.
3. Run on an Android 12+ device/emulator and grant Music and audio permission when prompted (runtime permission UI still needs to be added in this starter).
4. Debug APK: `./gradlew assembleDebug`
5. Release APK: `./gradlew assembleRelease`

Generated APKs are placed under `app/build/outputs/apk/`.

## Notes
- No INTERNET permission or online services are declared.
- Release signing is not configured; configure your own keystore before distributing a signed release.
- APK size is not guaranteed. A 50 MB target must be measured after a real release build and should not be achieved by adding filler.
- Gradle wrapper files are not bundled in this source archive; generate them with an installed Gradle (`gradle wrapper`) or open the project in Android Studio.
